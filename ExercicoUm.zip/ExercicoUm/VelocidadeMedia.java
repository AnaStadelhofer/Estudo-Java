package ExercicoUm;
// 6) Crie um programa que calcule a velocidade média de uma viagem (distancia (km) / tempo (h)) 

public class VelocidadeMedia {
    public static void main(String[] args) {
        int km = 100;
        int tempo = 10;
        int velocidade = km / tempo;

        System.out.println(velocidade);
        
    }
}
