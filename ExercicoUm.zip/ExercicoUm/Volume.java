package ExercicoUm;
//  3) Crie um programa que calcule o volume (largura * altura * profundidade)
public class Volume {
    public static void main(String[] args) {
        System.out.println("HELOWOR");

        int largura = 10;
        int altura = 10;
        int profundidade = 15;

        int volume = largura * altura * profundidade;
        System.out.println(volume);
    }
}
