package ExercicoUm;
// 1) Crie um programa que calcule a média ((nota1 + nota2 + nota3 / 3))
public class MediaAluno {
    public static void main(String[] args) {
        System.out.println("HELOWOR");
        int nota1 = 9;
        int nota2 = 9;
        int nota3 = 10;

        int media = (nota1 + nota2 + nota3) / 3;

        System.out.println(media);
    }
}
