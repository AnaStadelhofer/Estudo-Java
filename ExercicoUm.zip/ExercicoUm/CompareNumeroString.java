package ExercicoUm;
//  10) Crie um programa que compare dois valores Strings
public class CompareNumeroString {
    public static void main(String[] args) {
        
    }
}
