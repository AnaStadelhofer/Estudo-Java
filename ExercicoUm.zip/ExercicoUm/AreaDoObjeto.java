package ExercicoUm;
// Crie um programa que calcule a área (lado1 * lado2) 
public class AreaDoObjeto {
    public static void main(String[] args) {
        System.out.println("HELOWOR");

        int largura = 10;
        int altura = 10;

        int area = largura * altura;
        System.out.println(area);
    }
}
