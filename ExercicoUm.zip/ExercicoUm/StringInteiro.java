package ExercicoUm;
// Crie um programa que tenha uma variável com ponto em String e converta seu valor para inteiro
public class StringInteiro {
    public static void main(String[] args) {
        
    }
}
